"""
Resume Parser (Module 1).

Takes raw resume text, sends it to the LLM with a strict prompt asking
for structured JSON, then validates that JSON against a schema before
it's trusted anywhere downstream (semantic search, CV suggestions, etc).
"""

import json

from google import genai
from pydantic import BaseModel, Field, ValidationError

from src.config import GEMINI_API_KEY, GEMINI_MODEL
from src.llm_utils import llm_retry

_client = genai.Client(api_key=GEMINI_API_KEY)


# --- Schema --------------------------------------------------------------
class Experience(BaseModel):
    title: str
    company: str
    duration: str = Field(description="e.g. 'Jan 2024 - Present'")
    highlights: list[str] = Field(default_factory=list)


class Education(BaseModel):
    degree: str
    institution: str
    year: str = ""
    gpa: str = ""


class ResumeProfile(BaseModel):
    name: str
    email: str = ""
    phone: str = ""
    target_role: str = Field(
        default="", description="Role the candidate appears to be aiming for"
    )
    skills: list[str] = Field(default_factory=list)
    experience: list[Experience] = Field(default_factory=list)
    education: list[Education] = Field(default_factory=list)
    summary: str = Field(
        default="", description="One or two sentence overview of the candidate"
    )


PARSE_SYSTEM_PROMPT = """You are a precise resume-parsing engine.

Read the resume text and extract fields into JSON that matches this schema:
- name (string)
- email (string, "" if not found)
- phone (string, "" if not found)
- target_role (string — infer the most likely role this candidate is
  aiming for from their most recent experience/skills; "" if unclear)
- skills (array of strings — deduplicated, no categories, just skill names)
- experience (array of objects: title, company, duration, highlights[])
- education (array of objects: degree, institution, year, gpa)
- summary (string — 1-2 sentence neutral overview, written by you)

Rules:
- Output ONLY valid JSON. No markdown fences, no commentary, no preamble.
- Never invent information that isn't in the resume. Use "" or [] for
  anything missing.
- Keep "highlights" as short bullet-style strings, not full paragraphs.
"""


@llm_retry
def _call_llm(resume_text: str):
    """Gemini call wrapped with retry-on-503/500/429 (see src/llm_utils.py)."""
    return _client.models.generate_content(
        model=GEMINI_MODEL,
        contents=[
            {"role": "user", "parts": [{"text": PARSE_SYSTEM_PROMPT}]},
            {
                "role": "user",
                "parts": [{"text": f"Resume text:\n\n{resume_text}"}],
            },
        ],
        config={
            "response_mime_type": "application/json",
            "temperature": 0.1,
        },
    )


def parse_resume(resume_text: str) -> ResumeProfile:
    """
    Send resume text to the LLM and return a validated ResumeProfile.
    Raises ValueError if the model's output doesn't validate, so callers
    never accidentally work with malformed data.
    """
    response = _call_llm(resume_text)
    raw = response.text.strip()

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Model did not return valid JSON: {exc}\nRaw: {raw}")

    try:
        profile = ResumeProfile.model_validate(data)
    except ValidationError as exc:
        raise ValueError(f"Parsed JSON failed schema validation: {exc}")

    return profile


if __name__ == "__main__":
    # Quick manual smoke test:
    #   python -m src.parsing.resume_parser data/resumes/sample.pdf
    import sys

    from src.parsing.loader import load_resume

    if len(sys.argv) != 2:
        print("Usage: python -m src.parsing.resume_parser <resume_path>")
        raise SystemExit(1)

    text = load_resume(sys.argv[1])
    profile = parse_resume(text)
    print(profile.model_dump_json(indent=2))

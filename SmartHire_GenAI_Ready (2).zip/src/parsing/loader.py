"""
Document loading & chunking.

Handles pulling raw text out of a resume (PDF or DOCX) and, separately,
splitting any long document into overlapping chunks — used later for
the career-notes corpus that the RAG mentor retrieves from.
"""

from pathlib import Path

from pypdf import PdfReader
import docx

from src.config import CHUNK_OVERLAP, CHUNK_SIZE, MAX_RESUME_CHARS


class UnsupportedFileType(Exception):
    """Raised when a file isn't a .pdf or .docx."""


def load_pdf(path: str | Path) -> str:
    """Extract raw text from a PDF, page by page."""
    reader = PdfReader(str(path))
    pages = [page.extract_text() or "" for page in reader.pages]
    return "\n".join(pages).strip()


def load_docx(path: str | Path) -> str:
    """Extract raw text from a DOCX, paragraph by paragraph."""
    document = docx.Document(str(path))
    paragraphs = [p.text for p in document.paragraphs if p.text.strip()]
    return "\n".join(paragraphs).strip()


def load_resume(path: str | Path) -> str:
    """
    Load a resume file (.pdf or .docx) and return its raw text.
    Truncates to MAX_RESUME_CHARS as a basic guardrail against
    accidentally feeding a huge file to the LLM.
    """
    path = Path(path)
    suffix = path.suffix.lower()

    if suffix == ".pdf":
        text = load_pdf(path)
    elif suffix == ".docx":
        text = load_docx(path)
    else:
        raise UnsupportedFileType(
            f"'{suffix}' is not supported — upload a .pdf or .docx resume."
        )

    if not text:
        raise ValueError(
            "No extractable text found. The file may be a scanned image "
            "PDF with no text layer."
        )

    return text[:MAX_RESUME_CHARS]


def chunk_text(
    text: str,
    chunk_size: int = CHUNK_SIZE,
    overlap: int = CHUNK_OVERLAP,
) -> list[str]:
    """
    Split text into overlapping chunks for embedding.
    Simple character-based sliding window — good enough for career
    notes and job descriptions, which aren't huge documents.
    """
    if overlap >= chunk_size:
        raise ValueError("overlap must be smaller than chunk_size")

    chunks = []
    start = 0
    text_len = len(text)

    while start < text_len:
        end = start + chunk_size
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start += chunk_size - overlap

    return chunks


def load_and_chunk_career_notes(folder: str | Path) -> list[dict]:
    """
    Load every .txt/.md file in a folder and chunk it, tagging each
    chunk with its source filename so the mentor can later say where
    an answer came from.
    """
    folder = Path(folder)
    results = []

    for file_path in sorted(folder.glob("*")):
        if file_path.suffix.lower() not in (".txt", ".md"):
            continue
        text = file_path.read_text(encoding="utf-8")
        for i, chunk in enumerate(chunk_text(text)):
            results.append(
                {
                    "source": file_path.name,
                    "chunk_id": i,
                    "text": chunk,
                }
            )

    return results

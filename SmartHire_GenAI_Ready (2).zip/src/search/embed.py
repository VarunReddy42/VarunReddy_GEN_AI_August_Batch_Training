"""
Embeddings (used by Module 2 — Semantic Job Search).

Wraps Gemini's embedding model behind a couple of small, retry-wrapped
functions so the rest of the codebase never talks to the raw API
directly. Keeping this separate from job_search.py means the same
embedding function can be reused later for the career-notes corpus the
RAG mentor retrieves from.
"""

from google import genai

from src.config import EMBEDDING_MODEL, GEMINI_API_KEY
from src.llm_utils import llm_retry

_client = genai.Client(api_key=GEMINI_API_KEY)


@llm_retry
def _embed_batch(texts: list[str], task_type: str) -> list[list[float]]:
    """Single retry-wrapped call to the embeddings endpoint."""
    response = _client.models.embed_content(
        model=EMBEDDING_MODEL,
        contents=texts,
        config={"task_type": task_type},
    )
    return [e.values for e in response.embeddings]


def embed_documents(texts: list[str], batch_size: int = 32) -> list[list[float]]:
    """
    Embed a list of documents (job descriptions, career notes chunks)
    for storage in the vector index. Batches requests since the API
    caps how many texts can go in one call.
    """
    vectors: list[list[float]] = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        vectors.extend(_embed_batch(batch, task_type="RETRIEVAL_DOCUMENT"))
    return vectors


def embed_query(text: str) -> list[float]:
    """
    Embed a single query (a candidate profile, or a mentor question).
    Uses a different task_type than embed_documents — Gemini's
    embedding model is asymmetric, so queries and documents are
    embedded slightly differently for better retrieval quality.
    """
    return _embed_batch([text], task_type="RETRIEVAL_QUERY")[0]

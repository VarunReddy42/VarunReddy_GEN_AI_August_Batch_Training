"""
Semantic Job Search (Module 2).

Embeds a job corpus (a CSV with title/company/description columns),
stores the vectors in a FAISS index, and lets you query it with a
candidate profile to get back the top-N most relevant jobs.

Expected CSV columns: title, company, description, skills (skills is
optional — free text is fine).
"""

import json
import pickle
from pathlib import Path

import faiss
import numpy as np
import pandas as pd

from src.config import JOBS_DIR, VECTORSTORE_DIR
from src.search.embed import embed_documents, embed_query

INDEX_PATH = VECTORSTORE_DIR / "jobs.faiss"
METADATA_PATH = VECTORSTORE_DIR / "jobs_metadata.pkl"


def _normalize(vectors: np.ndarray) -> np.ndarray:
    """L2-normalize so inner product search behaves like cosine similarity."""
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms[norms == 0] = 1e-10
    return vectors / norms


def build_job_index(csv_path: str | Path) -> None:
    """
    Read the job corpus CSV, embed each job's description (title +
    description + skills combined for richer context), build a FAISS
    index, and save both the index and the row metadata to disk.
    """
    csv_path = Path(csv_path)
    df = pd.read_csv(csv_path)

    required = {"title", "company", "description"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Job CSV is missing required columns: {missing}")

    df = df.fillna("")

    texts = [
        f"{row.title}. {row.description} Skills: {getattr(row, 'skills', '')}"
        for row in df.itertuples()
    ]

    print(f"Embedding {len(texts)} job postings...")
    vectors = np.array(embed_documents(texts), dtype="float32")
    vectors = _normalize(vectors)

    dimension = vectors.shape[1]
    index = faiss.IndexFlatIP(dimension)
    index.add(vectors)

    VECTORSTORE_DIR.mkdir(parents=True, exist_ok=True)
    faiss.write_index(index, str(INDEX_PATH))

    metadata = df.to_dict(orient="records")
    with open(METADATA_PATH, "wb") as f:
        pickle.dump(metadata, f)

    print(f"Indexed {len(metadata)} jobs -> {INDEX_PATH}")


def load_job_index() -> tuple[faiss.Index, list[dict]]:
    """Load the saved FAISS index and its row metadata from disk."""
    if not INDEX_PATH.exists() or not METADATA_PATH.exists():
        raise FileNotFoundError(
            "No job index found. Run build_job_index() first — "
            "e.g. `python -m src.search.job_search data/jobs/sample_jobs.csv`."
        )

    index = faiss.read_index(str(INDEX_PATH))
    with open(METADATA_PATH, "rb") as f:
        metadata = pickle.load(f)

    return index, metadata


def search_jobs(profile_text: str, top_n: int = 5) -> list[dict]:
    """
    Embed a candidate profile (or any free-text query) and return the
    top_n most similar jobs, each with a similarity score attached.
    """
    index, metadata = load_job_index()

    query_vector = np.array([embed_query(profile_text)], dtype="float32")
    query_vector = _normalize(query_vector)

    scores, indices = index.search(query_vector, top_n)

    results = []
    for score, idx in zip(scores[0], indices[0]):
        if idx == -1:
            continue
        job = dict(metadata[idx])
        job["similarity_score"] = round(float(score), 4)
        results.append(job)

    return results


if __name__ == "__main__":
    # Build the index:
    #   python -m src.search.job_search data/jobs/sample_jobs.csv
    # Then re-run with no args to test a search against a demo profile:
    #   python -m src.search.job_search
    import sys

    if len(sys.argv) == 2:
        build_job_index(sys.argv[1])
    else:
        demo_profile = (
            "Python developer with SQL, Pandas, and data visualization "
            "experience, looking for a Data Analyst role."
        )
        for job in search_jobs(demo_profile, top_n=3):
            print(json.dumps(job, indent=2))

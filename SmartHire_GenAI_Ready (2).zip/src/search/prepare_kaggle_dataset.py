"""
Prepare the real Kaggle LinkedIn Job Postings dataset for indexing.

Dataset: "LinkedIn Job Postings (2023-2024)" by arshkon
https://www.kaggle.com/datasets/arshkon/linkedin-job-postings

Download it (you'll need a free Kaggle account), unzip it, and point
this script at the folder containing job_postings.csv and
companies.csv. It merges the two on company_id, samples/cleans the
columns down to what job_search.py expects (title, company,
description, skills), and writes data/jobs/real_jobs.csv.

Usage:
    python -m src.search.prepare_kaggle_dataset /path/to/unzipped/dataset
"""

import sys
from pathlib import Path

import pandas as pd

from src.config import JOBS_DIR


def prepare(dataset_folder: str | Path, max_rows: int | None = 2000) -> Path:
    dataset_folder = Path(dataset_folder)
    postings_path = dataset_folder / "job_postings.csv"
    companies_path = dataset_folder / "companies.csv"

    if not postings_path.exists() or not companies_path.exists():
        raise FileNotFoundError(
            f"Expected job_postings.csv and companies.csv in {dataset_folder}. "
            "Did you unzip the Kaggle download fully?"
        )

    print("Loading job_postings.csv...")
    postings = pd.read_csv(postings_path, usecols=["title", "description", "company_id"])

    print("Loading companies.csv...")
    companies = pd.read_csv(companies_path, usecols=["company_id", "name"])

    merged = postings.merge(companies, on="company_id", how="left")
    merged = merged.rename(columns={"name": "company"})
    merged["company"] = merged["company"].fillna("Unknown Company")
    merged["skills"] = ""  # this dataset's skills live in a separate file; optional to merge in later
    merged = merged.dropna(subset=["title", "description"])

    if max_rows:
        merged = merged.sample(n=min(max_rows, len(merged)), random_state=42)

    out_path = JOBS_DIR / "real_jobs.csv"
    merged[["title", "company", "description", "skills"]].to_csv(out_path, index=False)
    print(f"Wrote {len(merged)} real job postings -> {out_path}")
    return out_path


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python -m src.search.prepare_kaggle_dataset /path/to/unzipped/dataset")
        raise SystemExit(1)
    prepare(sys.argv[1])

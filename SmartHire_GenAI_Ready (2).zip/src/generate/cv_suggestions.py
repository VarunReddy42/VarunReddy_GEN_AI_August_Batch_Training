"""
CV Improvement Generator (Module 3).

Given a parsed resume profile and a target job, calls the LLM (using
the prompt library) to produce missing-skill gaps, rewritten weak
bullet points, and a tailored summary — then validates the shape of
what comes back before handing it to the UI.
"""

import json

from google import genai
from pydantic import BaseModel, ValidationError

from src.config import GEMINI_API_KEY, GEMINI_MODEL
from src.generate.prompts import cv_suggestions_prompt
from src.llm_utils import llm_retry

_client = genai.Client(api_key=GEMINI_API_KEY)


@llm_retry
def _call_llm(prompt: str):
    """Gemini call wrapped with retry-on-503/500/429 (see src/llm_utils.py)."""
    return _client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt,
        config={
            "response_mime_type": "application/json",
            "temperature": 0.4,
        },
    )


class WeakBullet(BaseModel):
    original: str
    why_weak: str
    improved: str


class CVSuggestions(BaseModel):
    missing_skills: list[str] = []
    weak_bullets: list[WeakBullet] = []
    rewritten_summary: str = ""


def generate_cv_suggestions(profile_json: dict, target_job: dict) -> CVSuggestions:
    """
    Run the CV-improvement prompt against the LLM and return validated
    suggestions. profile_json is expected to be a ResumeProfile dict
    (see src/parsing/resume_parser.py); target_job is a dict with at
    least 'title' and 'description'.
    """
    prompt = cv_suggestions_prompt(profile_json, target_job)
    response = _call_llm(prompt)
    raw = response.text.strip()

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Model did not return valid JSON: {exc}\nRaw: {raw}")

    try:
        return CVSuggestions.model_validate(data)
    except ValidationError as exc:
        raise ValueError(f"Suggestions JSON failed schema validation: {exc}")


if __name__ == "__main__":
    # Quick manual smoke test with a fake profile + job, so this can be
    # sanity-checked before the resume parser / job search are wired in.
    demo_profile = {
        "name": "Test Candidate",
        "skills": ["Python", "Pandas", "SQL"],
        "experience": [
            {
                "title": "Data Analyst Intern",
                "company": "Acme Corp",
                "duration": "Jun 2025 - Aug 2025",
                "highlights": ["Worked on dashboards", "Helped the team with reports"],
            }
        ],
        "education": [],
        "target_role": "Data Analyst",
        "summary": "",
    }
    demo_job = {
        "title": "Data Analyst",
        "company": "Globex",
        "description": (
            "Looking for a Data Analyst with strong SQL, Python, Tableau, "
            "and A/B testing experience to drive product decisions."
        ),
    }

    result = generate_cv_suggestions(demo_profile, demo_job)
    print(result.model_dump_json(indent=2))

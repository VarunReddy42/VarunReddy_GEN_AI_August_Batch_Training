"""
AI Career Mentor (Module 4) — RAG pipeline orchestrated with LangChain.

Retrieves relevant chunks from the career-notes corpus (and, later, the
job corpus) via a LangChain FAISS vectorstore, then grounds Gemini's
answer strictly in what was retrieved so the mentor stays factual
instead of free-generating career advice.

Guardrails (Module 5, Week 3) will sit in front of `ask_mentor` — for
now this module assumes the input has already been validated.
"""

from pathlib import Path

from google import genai
from langchain_core.embeddings import Embeddings
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda, RunnablePassthrough
from langchain_community.vectorstores import FAISS

from src.config import CAREER_NOTES_DIR, GEMINI_API_KEY, GEMINI_MODEL, VECTORSTORE_DIR
from src.generate.prompts import career_mentor_system_prompt
from src.llm_utils import llm_retry
from src.parsing.loader import load_and_chunk_career_notes
from src.safety.guardrails import check_input
from src.search.embed import embed_documents, embed_query

NOTES_INDEX_DIR = VECTORSTORE_DIR / "career_notes_faiss"

_client = genai.Client(api_key=GEMINI_API_KEY)


class GeminiEmbeddings(Embeddings):
    """
    Thin adapter so LangChain's FAISS vectorstore can call our existing,
    retry-wrapped Gemini embedding functions (src/search/embed.py)
    instead of needing a separate LangChain-Google integration package.
    """

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return embed_documents(texts)

    def embed_query(self, text: str) -> list[float]:
        return embed_query(text)


def build_notes_index(folder: str | Path = CAREER_NOTES_DIR) -> None:
    """
    Load + chunk every career note doc, embed the chunks, and save a
    LangChain FAISS vectorstore to disk for the mentor to retrieve from.
    """
    chunks = load_and_chunk_career_notes(folder)
    if not chunks:
        raise ValueError(
            f"No .txt/.md career notes found in {folder} — add some first."
        )

    texts = [c["text"] for c in chunks]
    metadatas = [{"source": c["source"], "chunk_id": c["chunk_id"]} for c in chunks]

    print(f"Embedding {len(texts)} career-notes chunks...")
    vectorstore = FAISS.from_texts(
        texts=texts, embedding=GeminiEmbeddings(), metadatas=metadatas
    )

    NOTES_INDEX_DIR.mkdir(parents=True, exist_ok=True)
    vectorstore.save_local(str(NOTES_INDEX_DIR))
    print(f"Saved career-notes index -> {NOTES_INDEX_DIR}")


def _load_notes_index() -> FAISS:
    if not NOTES_INDEX_DIR.exists():
        raise FileNotFoundError(
            "No career-notes index found. Run build_notes_index() first — "
            "e.g. `python -m src.mentor.rag_chain build`."
        )
    # allow_dangerous_deserialization is safe here: this index is one we
    # built ourselves from local files, not one loaded from an untrusted
    # source.
    return FAISS.load_local(
        str(NOTES_INDEX_DIR),
        embeddings=GeminiEmbeddings(),
        allow_dangerous_deserialization=True,
    )


def _format_docs(docs) -> str:
    """Render retrieved chunks with their source, so answers can point back to them."""
    return "\n\n".join(f"[Source: {d.metadata['source']}]\n{d.page_content}" for d in docs)


@llm_retry
def _call_gemini(prompt_text: str) -> str:
    """Gemini call wrapped with retry-on-503/500/429 (see src/llm_utils.py)."""
    response = _client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt_text,
        config={"temperature": 0.3},
    )
    return response.text.strip()


def build_mentor_chain():
    """
    Build the LangChain LCEL pipeline:
    retriever -> format context -> prompt -> Gemini -> plain string.
    """
    vectorstore = _load_notes_index()
    retriever = vectorstore.as_retriever(search_kwargs={"k": 4})

    prompt = ChatPromptTemplate.from_template(
        career_mentor_system_prompt()
        + "\n\nRetrieved context:\n{context}\n\nUser question: {question}"
    )

    chain = (
        {"context": retriever | _format_docs, "question": RunnablePassthrough()}
        | prompt
        | RunnableLambda(lambda prompt_value: _call_gemini(prompt_value.to_string()))
        | StrOutputParser()
    )
    return chain


def ask_mentor(question: str) -> str:
    """
    Answer one career question, after passing it through the guardrails
    layer (Module 5). Returns a plain refusal message instead of calling
    the LLM at all if the input is blocked.
    """
    guard = check_input(question)
    if not guard.allowed:
        return (
            "I can't help with that — "
            f"{guard.reason} Ask me a career or job-search question instead."
        )

    chain = build_mentor_chain()
    return chain.invoke(question)


if __name__ == "__main__":
    # Build the index:
    #   python -m src.mentor.rag_chain build
    # Ask a question (uses the already-built index):
    #   python -m src.mentor.rag_chain "How do I switch to Data Analyst?"
    import sys

    if len(sys.argv) < 2:
        print(
            'Usage:\n'
            '  python -m src.mentor.rag_chain build\n'
            '  python -m src.mentor.rag_chain "your question here"'
        )
        raise SystemExit(1)

    if sys.argv[1] == "build":
        build_notes_index()
    else:
        question = " ".join(sys.argv[1:])
        print(ask_mentor(question))

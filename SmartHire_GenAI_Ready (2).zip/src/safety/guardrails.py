"""
Guardrails Layer (Module 5).

Two layers of defense before any user input reaches the mentor (or any
other LLM call):
  1. Fast, rule-based checks — empty input, absurd length, and a small
     blocklist of obvious prompt-injection phrases. These run with no
     API call, so they catch the cheap/obvious cases instantly.
  2. An LLM-based classifier — catches off-topic or unsafe requests
     that don't contain an obvious trigger phrase but are clearly
     outside the mentor's scope.

Both must pass for input to be allowed through.
"""

from dataclasses import dataclass

from google import genai

from src.config import GEMINI_API_KEY, GEMINI_MODEL
from src.generate.prompts import guardrail_input_check_prompt
from src.llm_utils import llm_retry

_client = genai.Client(api_key=GEMINI_API_KEY)

MAX_QUESTION_CHARS = 2000

# Obvious prompt-injection / jailbreak phrases. Not exhaustive — this is
# a fast first pass, not the only line of defense (the LLM classifier
# below covers what this misses).
INJECTION_PATTERNS = [
    "ignore previous instructions",
    "ignore all previous instructions",
    "disregard your instructions",
    "you are now",
    "act as if you have no restrictions",
    "system prompt",
    "reveal your instructions",
    "jailbreak",
]


@dataclass
class GuardrailResult:
    allowed: bool
    reason: str = ""


def rule_based_check(text: str) -> GuardrailResult:
    """Fast, free checks that don't need an API call."""
    stripped = text.strip()

    if not stripped:
        return GuardrailResult(False, "Empty input.")

    if len(stripped) > MAX_QUESTION_CHARS:
        return GuardrailResult(
            False, f"Input too long (max {MAX_QUESTION_CHARS} characters)."
        )

    lowered = stripped.lower()
    for pattern in INJECTION_PATTERNS:
        if pattern in lowered:
            return GuardrailResult(
                False, "Input contains a disallowed instruction-override phrase."
            )

    return GuardrailResult(True)


@llm_retry
def _classify_with_llm(text: str) -> str:
    """Ask Gemini to classify the input as ALLOW or BLOCK. Returns the raw label."""
    response = _client.models.generate_content(
        model=GEMINI_MODEL,
        contents=guardrail_input_check_prompt(text),
        config={"temperature": 0.0},
    )
    return response.text.strip().upper()


def llm_based_check(text: str) -> GuardrailResult:
    """Slower, semantic check for off-topic / unsafe requests the rules miss."""
    label = _classify_with_llm(text)
    if "BLOCK" in label:
        return GuardrailResult(
            False, "This doesn't look like a career/job-search question."
        )
    return GuardrailResult(True)


def check_input(text: str, use_llm: bool = True) -> GuardrailResult:
    """
    Run both guardrail layers. Rule-based check runs first and short-
    circuits (no API call) if it already fails. Set use_llm=False to
    skip the semantic check, e.g. in tests or when minimizing API calls.
    """
    result = rule_based_check(text)
    if not result.allowed:
        return result

    if use_llm:
        return llm_based_check(text)

    return GuardrailResult(True)


if __name__ == "__main__":
    # Quick manual smoke test:
    #   python -m src.safety.guardrails "How do I switch to Data Analyst?"
    import sys

    if len(sys.argv) < 2:
        print('Usage: python -m src.safety.guardrails "some input"')
        raise SystemExit(1)

    text = " ".join(sys.argv[1:])
    result = check_input(text)
    print(f"allowed={result.allowed} reason={result.reason!r}")

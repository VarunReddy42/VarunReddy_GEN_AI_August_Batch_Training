# Switching into Data Analytics

If you're coming from a software engineering or general CS background and
want to move into Data Analytics, focus on these areas:

- **SQL** is the single most important skill — practice writing joins,
  window functions, and aggregations until they're second nature.
- **Data visualization** tools like Tableau or Power BI matter more than
  people expect. Being able to tell a story with a chart is a big part
  of the job.
- **A/B testing and basic statistics** (means, confidence intervals,
  p-values) come up constantly in interviews.
- A portfolio project analyzing a public dataset (Kaggle is a good
  source) and presenting findings clearly is worth more than another
  algorithm-heavy coding project.
- You do NOT need deep machine learning knowledge for most Data Analyst
  roles — that's more relevant for Data Scientist positions.

Typical interview loop: a SQL screen, a case-study / take-home analysis,
and a behavioral round focused on how you communicate findings to
non-technical stakeholders.

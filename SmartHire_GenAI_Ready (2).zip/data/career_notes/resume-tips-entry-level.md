# Resume Tips for Entry-Level Tech Roles

- Lead each bullet point with an action verb and, where possible, a
  number: "Reduced page load time by 30%" beats "Worked on performance."
- Keep a resume to one page for entry-level and internship applications.
  Recruiters spend seconds on a first pass.
- List your strongest, most relevant projects first — not
  chronologically by class or club.
- Avoid listing every technology you've ever touched. Group skills by
  category (Languages, Frameworks, Tools) and only include what you can
  speak to confidently in an interview.
- A GitHub link with active, well-documented repositories is one of the
  highest-signal things you can add to a resume for a technical role.
- Tailor the "summary" or objective line to the specific role you're
  applying for — a generic summary reads as low-effort.

## Common weak bullet patterns to avoid

- Responsibility-only bullets with no outcome ("Responsible for
  managing the database") — rewrite to show impact.
- Passive voice ("Was involved in the redesign of...") — rewrite in
  active voice with you as the subject.
- Vague scale claims ("Worked with large datasets") — replace with an
  actual number or range if you have one, or drop the claim.
